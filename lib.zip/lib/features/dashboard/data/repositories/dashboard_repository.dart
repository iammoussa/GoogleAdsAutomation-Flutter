import 'package:frontend/core/network/api_service.dart';
import 'package:frontend/features/dashboard/domain/entities/dashboard_stats.dart';

class DashboardRepository {
  final ApiService apiService;

  DashboardRepository({required this.apiService});

  /// Get dashboard stats with optional date range
  Future<DashboardStats> getStats({
    String? startDate,
    String? endDate,
  }) async {
    try {
      // Build endpoint with parameters
      final params = <String, String>{};

      if (startDate != null && endDate != null) {
        params['start_date'] = startDate;
        params['end_date'] = endDate;
      }

      // Build query string
      String endpoint = '/api/stats/dashboard';
      if (params.isNotEmpty) {
        final queryString = params.entries
            .map((e) => '${e.key}=${Uri.encodeComponent(e.value)}')
            .join('&');
        endpoint += '?$queryString';
      }

      final response = await apiService.get(endpoint);
      return DashboardStats.fromJson(response);
    } catch (e) {
      print('Error getting dashboard stats: $e');
      rethrow;
    }
  }

  /// Get pending optimizations count
  Future<int> getPendingOptimizationsCount() async {
    try {
      final response = await apiService.get('/api/optimizations/count?status=pending');
      return response['count'] as int? ?? 0;
    } catch (e) {
      print('Error getting optimizations count: $e');
      rethrow;
    }
  }
}