import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:frontend/features/campaigns/data/models/campaign.dart';
import 'package:frontend/features/campaigns/data/repositories/campaign_repository.dart';
import 'package:frontend/features/dashboard/data/repositories/dashboard_repository.dart';
import 'package:frontend/features/dashboard/domain/entities/dashboard_stats.dart';
import 'package:frontend/features/dashboard/presentation/widgets/period_selector.dart';

part 'dashboard_state.dart';

class DashboardCubit extends Cubit<DashboardState> {
  final DashboardRepository dashboardRepository;
  final CampaignRepository campaignRepository;

  DashboardCubit({
    required this.dashboardRepository,
    required this.campaignRepository,
  }) : super(DashboardInitial());

  Future<void> loadDashboard({DateRangeOption? dateRange}) async {
    try {
      emit(DashboardLoading());

      // Load saved date range if not provided
      final range = dateRange ?? await PeriodSelector.loadSelectedRange();

      // SEMPRE fetch LIVE da Google Ads API con date range
      final results = await Future.wait([
        dashboardRepository.getStats(
          startDate: range.startDateFormatted,
          endDate: range.endDateFormatted,
        ),
        campaignRepository.getCampaigns(
          live: true,
          startDate: range.startDateFormatted,
          endDate: range.endDateFormatted,
        ),
        dashboardRepository.getPendingOptimizationsCount(),
      ]);

      final stats = results[0] as DashboardStats;
      final campaigns = results[1] as List<Campaign>;
      final pendingCount = results[2] as int;

      final topCampaigns = campaigns.take(5).toList();

      emit(DashboardLoaded(
        stats: stats,
        campaigns: topCampaigns,
        pendingOptimizations: pendingCount,
        selectedDateRange: range,
        selectedFilter: 'Tutte',
      ));
    } catch (e) {
      print('Error loading dashboard: $e');
      emit(DashboardError(e.toString()));
    }
  }

  Future<void> changePeriod(DateRangeOption range) async {
    final currentState = state;
    if (currentState is! DashboardLoaded) return;

    try {
      // Show loading overlay but keep current data visible
      emit(DashboardLoaded(
        stats: currentState.stats,
        campaigns: currentState.campaigns,
        pendingOptimizations: currentState.pendingOptimizations,
        selectedDateRange: range,
        selectedFilter: currentState.selectedFilter,
        isRefreshing: true,
      ));

      // FETCH LIVE da Google Ads con nuovo range
      final results = await Future.wait([
        dashboardRepository.getStats(
          startDate: range.startDateFormatted,
          endDate: range.endDateFormatted,
        ),
        campaignRepository.getCampaigns(
          live: true,
          startDate: range.startDateFormatted,
          endDate: range.endDateFormatted,
        ),
      ]);

      final stats = results[0] as DashboardStats;
      final campaigns = results[1] as List<Campaign>;

      List<Campaign> filteredCampaigns = _applyFilter(
        campaigns,
        currentState.selectedFilter,
      );

      final topCampaigns = filteredCampaigns.take(5).toList();

      emit(DashboardLoaded(
        stats: stats,
        campaigns: topCampaigns,
        pendingOptimizations: currentState.pendingOptimizations,
        selectedDateRange: range,
        selectedFilter: currentState.selectedFilter,
      ));
    } catch (e) {
      print('Error changing period: $e');
      emit(DashboardError(e.toString()));
    }
  }

  Future<void> filterCampaigns(String filter) async {
    final currentState = state;
    if (currentState is! DashboardLoaded) return;

    try {
      // FETCH LIVE da Google Ads con date range corrente
      final campaigns = await campaignRepository.getCampaigns(
        live: true,
        startDate: currentState.selectedDateRange.startDateFormatted,
        endDate: currentState.selectedDateRange.endDateFormatted,
      );

      final filteredCampaigns = _applyFilter(campaigns, filter);
      final topCampaigns = filteredCampaigns.take(5).toList();

      emit(currentState.copyWith(
        campaigns: topCampaigns,
        selectedFilter: filter,
      ));
    } catch (e) {
      print('Error filtering campaigns: $e');
      emit(DashboardError(e.toString()));
    }
  }

  List<Campaign> _applyFilter(List<Campaign> campaigns, String filter) {
    switch (filter) {
      case 'Attive':
        return campaigns
            .where((c) => c.status.toUpperCase() == 'ENABLED')
            .toList();
      case 'In pausa':
        return campaigns
            .where((c) => c.status.toUpperCase() == 'PAUSED')
            .toList();
      case 'Attenzione':
        return campaigns
            .where((c) => c.cost > 1000 || c.ctr < 1.0)
            .toList();
      default: // 'Tutte'
        return campaigns;
    }
  }

  Future<void> refreshDashboard() async {
    final currentState = state;
    final dateRange = currentState is DashboardLoaded
        ? currentState.selectedDateRange
        : await PeriodSelector.loadSelectedRange();
    await loadDashboard(dateRange: dateRange);
  }
}