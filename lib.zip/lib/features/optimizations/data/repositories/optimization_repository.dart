import 'package:frontend/core/network/api_service.dart';
import 'package:frontend/features/optimizations/data/models/optimization.dart';

class OptimizationRepository {
  final ApiService apiService;

  OptimizationRepository({required this.apiService});

  Future<List<Optimization>> getOptimizations() async {
    try {
      final response = await apiService.get('/api/optimizations');
      final List<dynamic> data = response['optimizations'] ?? [];
      return data.map((json) => Optimization.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching optimizations: $e');
      return [];
    }
  }

  Future<void> applyOptimization(int id) async {
    try {
      await apiService.post('/api/optimizations/$id/apply', body: {});
    } catch (e) {
      print('Error applying optimization: $e');
      rethrow;
    }
  }

  Future<void> dismissOptimization(int id) async {
    try {
      await apiService.post('/api/optimizations/$id/dismiss', body: {});
    } catch (e) {
      print('Error dismissing optimization: $e');
      rethrow;
    }
  }
}