import 'package:frontend/core/network/api_service.dart';
import '../models/campaign.dart';

class CampaignRepository {
  final ApiService apiService;

  CampaignRepository({required this.apiService});

  /// Get all campaigns from API with optional date range
  Future<List<Campaign>> getCampaigns({
    bool live = false,
    String? startDate,
    String? endDate,
  }) async {
    try {
      // Build endpoint with parameters
      final params = <String, String>{};

      if (live) {
        params['live'] = 'true';
      }

      if (startDate != null && endDate != null) {
        params['start_date'] = startDate;
        params['end_date'] = endDate;
      }

      // Build query string
      String endpoint = '/api/campaigns';
      if (params.isNotEmpty) {
        final queryString = params.entries
            .map((e) => '${e.key}=${Uri.encodeComponent(e.value)}')
            .join('&');
        endpoint += '?$queryString';
      }

      final response = await apiService.get(endpoint);

      // Extract campaigns array
      final campaignsJson = response['campaigns'] as List;

      // Convert to List<Campaign>
      return campaignsJson
          .map((json) => Campaign.fromJson(json as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('Error getting campaigns: $e');
      rethrow;
    }
  }

  /// Get single campaign by ID
  Future<Campaign> getCampaignById(String campaignId) async {
    try {
      final response = await apiService.get('/api/campaigns/$campaignId');
      return Campaign.fromJson(response);
    } catch (e) {
      print('Error getting campaign $campaignId: $e');
      rethrow;
    }
  }

  /// Sync campaigns from Google Ads API
  Future<void> syncCampaigns() async {
    try {
      await apiService.post('/api/campaigns/sync', body: {});
    } catch (e) {
      print('Error syncing campaigns: $e');
      rethrow;
    }
  }
}