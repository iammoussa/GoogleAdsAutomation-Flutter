class Campaign {
  final String campaignId;
  final String campaignName;
  final int impressions;
  final int clicks;
  final double conversions;
  final double cost;
  final double ctr;
  final double cpa;
  final double conversionRate;
  final String status;
  final String? lastUpdated;

  Campaign({
    required this.campaignId,
    required this.campaignName,
    required this.impressions,
    required this.clicks,
    required this.conversions,
    required this.cost,
    required this.ctr,
    required this.cpa,
    required this.conversionRate,
    required this.status,
    this.lastUpdated,
  });

  factory Campaign.fromJson(Map<String, dynamic> json) {
    return Campaign(
      campaignId: json['campaign_id'] as String,
      campaignName: json['campaign_name'] as String,
      impressions: json['impressions'] as int? ?? 0,
      clicks: json['clicks'] as int? ?? 0,
      conversions: (json['conversions'] as num?)?.toDouble() ?? 0.0,
      cost: (json['cost'] as num?)?.toDouble() ?? 0.0,
      ctr: (json['ctr'] as num?)?.toDouble() ?? 0.0,
      cpa: (json['cpa'] as num?)?.toDouble() ?? 0.0,
      conversionRate: (json['conversion_rate'] as num?)?.toDouble() ?? 0.0,
      status: json['status'] as String? ?? 'UNKNOWN',
      lastUpdated: json['last_updated'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'campaign_id': campaignId,
      'campaign_name': campaignName,
      'impressions': impressions,
      'clicks': clicks,
      'conversions': conversions,
      'cost': cost,
      'ctr': ctr,
      'cpa': cpa,
      'conversion_rate': conversionRate,
      'status': status,
      'last_updated': lastUpdated,
    };
  }
}