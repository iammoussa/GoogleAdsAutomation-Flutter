import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:8000';

  Future<Map<String, dynamic>> get(String endpoint, {bool live = false}) async {
    final url = live && endpoint.startsWith('/api/campaigns') && !endpoint.contains('?')
        ? '$baseUrl$endpoint?live=true'
        : '$baseUrl$endpoint';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load data: ${response.statusCode}');
      }
    } on SocketException {
      throw Exception('Network error: No internet connection');
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  Future<Map<String, dynamic>> post(
      String endpoint, {
        Map<String, dynamic>? body,
      }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$endpoint'),
        headers: {'Content-Type': 'application/json'},
        body: body != null ? json.encode(body) : null,
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to process request: ${response.statusCode}');
      }
    } on SocketException {
      throw Exception('Network error: No internet connection');
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }
}